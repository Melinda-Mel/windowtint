# WindowTint 0.2.0

WindowTint is a lightweight macOS menu-bar app that adds colored, non-clickable outlines around application windows. It helps distinguish windows in Mission Control without changing the contents of those applications.

## What it does

- Shows a stable color per app; common AI apps have named colors.
- Shows name labels in Mission Control only.
- Hides every outline outside Mission Control, keeping ordinary windows unobstructed.
- Tracks Mission Control transitions at up to 120 updates per second.
- Hides outlines during the Mission Control exit animation and keeps them hidden in normal working windows.

## Build locally

On a Mac with Xcode Command Line Tools installed:

```sh
chmod +x build-app.sh
./build-app.sh
open WindowTint.app
```

The app uses public macOS window information and does not request Accessibility or Screen Recording permission.

## Distribution note

This source package is MIT licensed. The separately provided prebuilt app is ad-hoc signed for local testing, not Apple notarized. To distribute it broadly to non-technical users, sign it with an Apple Developer ID and notarize a ZIP or DMG release first.

## Scope and limitation

WindowTint is a native runtime app, not a Codex Skill: it must remain running to draw window overlays. A Skill can help developers customize or build it, but cannot replace the app for end users.
